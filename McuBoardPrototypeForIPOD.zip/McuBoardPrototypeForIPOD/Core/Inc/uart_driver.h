/* File: uart_driver.h */
/* Why: Small helper driver that provides UART_Printf over UART1 */

#ifndef UART_DRIVER_H_                      // HE: הגנה מפני הכללה כפולה
#define UART_DRIVER_H_

#include "stm32f4xx_hal.h"                 // HE: טיפוס UART_HandleTypeDef

void UART_Printf(const char *fmt, ...);    // HE: printf דרך UART1

#endif /* UART_DRIVER_H_ */
