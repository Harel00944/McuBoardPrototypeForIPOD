/* File: gps.h */                                   // HE: כותרת דרייבר GPS פשוט ל NEO-M8L

#ifndef GPS_H                                       // HE: מניעת הגדרה כפולה של הקובץ
#define GPS_H                                       // HE: הגדרת המאקרו של הכותרת

#include "main.h"                                   // HE: כולל הגדרת UART_HandleTypeDef והפריפריות

typedef struct {                                    // HE: מבנה שמחזיק את נתוני ה GPS הפשוטים
    double  lat_deg;                                // HE: קו רוחב במעלות עשרוניות
    double  lon_deg;                                // HE: קו אורך במעלות עשרוניות
    double altitude_m;
    uint8_t used_gps;                               // HE: מספר לווייני GPS שמשתתפים בפיקס לפי GSA
    uint8_t used_glonass;                           // HE: מספר לווייני GLONASS שמשתתפים בפיקס לפי GSA
    uint8_t used_galileo;                           // HE: מספר לווייני GALILEO שמשתתפים בפיקס לפי GSA
    uint8_t used_beidou;                            // HE: מספר לווייני BEIDOU שמשתתפים בפיקס לפי GSA
    uint8_t hour;                                   // HE: שעה UTC
    uint8_t minute;                                 // HE: דקה UTC
    uint8_t second;                                 // HE: שניה UTC
    uint8_t fix;                                    // HE: 1 אם יש FIX, 0 אם אין FIX

} GPS_Data_t;                                       // HE: שם טיפוס המבנה

void GPS_Init(UART_HandleTypeDef *huart);          // HE: אתחול הדרייבר, קישור ל UART של ה GPS והתחלת קבלת אינטרפט
void GPS_RxCpltCallback(void);                     // HE: פונקציה שצריך לקרוא מתוך HAL_UART_RxCpltCallback
void GPS_PrintStatusLine(void);                    // HE: פונקציה שמדפיסה ל Tera Term את LAT LONG TIME FIX אם יש נתונים חדשים

#endif                                              // HE: סוף ההגדרה של GPS_H
