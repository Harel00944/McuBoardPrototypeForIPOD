/* File: st7735.h                                      // Header file that declares ST7735 driver API
   This header is included by main.c so that the TFT functions can be used */

#ifndef ST7735_H_                                      // Open include guard to prevent multiple inclusion of this file
#define ST7735_H_                                      // Define the include guard macro so the compiler knows it's active

#include "stm32f4xx_hal.h"                             // Include STM32 HAL header for GPIO and SPI structures and HAL functions
#include <stdint.h>                                     // Include standard integer type definitions such as uint8_t and uint16_t

#define ST7735_WIDTH   128                             // Logical width of the ST7735 display in pixels, used by drawing functions
#define ST7735_HEIGHT  160                             // Logical height of the ST7735 display in pixels, used for bounds checking

/* Pin mapping for control lines used by ST7735 */
#define ST7735_CS_GPIO    GPIOA                        // Chip Select control line is connected to GPIO port A
#define ST7735_CS_PIN     GPIO_PIN_4                   // Chip Select is assigned to pin PA4 on the MCU

#define ST7735_DC_GPIO    GPIOA                        // Data or Command select line is connected to GPIO port A
#define ST7735_DC_PIN     GPIO_PIN_8                   // Data or Command select is assigned to pin PA8

#define ST7735_RES_GPIO   GPIOA                        // Hardware Reset line for the display is connected to GPIO port A
#define ST7735_RES_PIN    GPIO_PIN_15                  // Reset line is assigned to pin PA15

/* SPI handle used for communication with display controller */
extern SPI_HandleTypeDef hspi1;                        // Declaration of the SPI1 handle that is created in CubeMX-generated spi.c
														// need it so the st773.c will be able to use spi functions like :HAL_SPI_Transmit(&hspi1, ...)

/* Color definitions in RGB565 format */
#define ST7735_COLOR_BLACK  0x0000                     // RGB565 code for black, used as background color
#define ST7735_COLOR_WHITE  0xFFFF                     // RGB565 code for white, used as foreground color

/* Public API function prototypes used by the main program */
void ST7735_Init(void);                                // Initialize display controller registers and exit sleep mode
void ST7735_FillScreen(uint16_t color);                // Fill entire screen area with the specified RGB565 color
void ST7735_ShowHarel(void);                           // Draw the word “HAREL” centered using a built-in mini font
void ST7735_ShowSentenceAt(const char *text,        // Draw a sentence at position (x, y)
                           uint16_t x,
                           uint16_t y,
                           uint16_t fg,
                           uint16_t bg);






/* New public functions for 5x7 text rendering */
void ST7735_DrawChar5x7(char c,            // Draws a single 5x7 character
                        uint16_t x,        // X coordinate on screen
                        uint16_t y,        // Y coordinate on screen
                        uint16_t fg,       // Foreground color
                        uint16_t bg);      // Background color behind pixels

void ST7735_DrawText5x7(const char *text,  // Draws a null-terminated string
                        uint16_t x,        // Starting X position
                        uint16_t y,        // Starting Y position
                        uint16_t fg,       // Foreground color
                        uint16_t bg);      // Background color
#endif /* ST7735_H_ */                                 // Close the include guard to finish file protection
