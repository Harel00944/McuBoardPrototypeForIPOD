/* File: BNO055.h */                               // HE: קובץ כותרת לדרייבר BNO055 עבור STM32
/* Why: מגדיר רגיסטרים, טיפוסים ופונקציות שהדרייבר BNO055.c משתמש בהם */

#ifndef INC_BNO055_H_
#define INC_BNO055_H_

#include <stdint.h>                                 // HE: טיפוסים uint8_t uint16_t int16_t
#include <stdbool.h>                                // HE: טיפוס bool

/* כתובת I2C של החיישן במצב ברירת מחדל */        // HE: 7bit address כפי שמופיע בדאטה שיט
#define BNO055_I2C_ADDR              0x28           // HE: הכתובת ללא ביט R/W הדרייבר מוסיף <<1

/* כתובות רגיסטרים עיקריים לפי הדאטה שיט */      // HE: טבלת רישומים של BNO055

#define BNO055_CHIP_ID               0x00           // HE: מזהה שבב צריך להיות 0xA0
#define BNO055_SW_REV_ID_LSB         0x04           // HE: גרסת תוכנה LSB
#define BNO055_SW_REV_ID_MSB         0x05           // HE: גרסת תוכנה MSB
#define BNO055_BL_REV_ID             0x06           // HE: גרסת bootloader
#define BNO055_PAGE_ID               0x07           // HE: בחירת עמוד 0 או 1

/* נתוני Accelerometer */                         // HE: וקטור תאוצה XYZ
#define BNO055_ACC_DATA_X_LSB        0x08
#define BNO055_ACC_DATA_X_MSB        0x09
#define BNO055_ACC_DATA_Y_LSB        0x0A
#define BNO055_ACC_DATA_Y_MSB        0x0B
#define BNO055_ACC_DATA_Z_LSB        0x0C
#define BNO055_ACC_DATA_Z_MSB        0x0D

/* נתוני Magnetometer */                          // HE: וקטור מגנטי XYZ
#define BNO055_MAG_DATA_X_LSB        0x0E
#define BNO055_MAG_DATA_X_MSB        0x0F
#define BNO055_MAG_DATA_Y_LSB        0x10
#define BNO055_MAG_DATA_Y_MSB        0x11
#define BNO055_MAG_DATA_Z_LSB        0x12
#define BNO055_MAG_DATA_Z_MSB        0x13

/* נתוני Gyroscope */                             // HE: וקטור ג'ירו XYZ
#define BNO055_GYR_DATA_X_LSB        0x14
#define BNO055_GYR_DATA_X_MSB        0x15
#define BNO055_GYR_DATA_Y_LSB        0x16
#define BNO055_GYR_DATA_Y_MSB        0x17
#define BNO055_GYR_DATA_Z_LSB        0x18
#define BNO055_GYR_DATA_Z_MSB        0x19

/* נתוני Euler vector: Heading Roll Pitch */      // HE: זוויות פיוז'ן
#define BNO055_EUL_HEADING_LSB       0x1A
#define BNO055_EUL_HEADING_MSB       0x1B
#define BNO055_EUL_ROLL_LSB          0x1C
#define BNO055_EUL_ROLL_MSB          0x1D
#define BNO055_EUL_PITCH_LSB         0x1E
#define BNO055_EUL_PITCH_MSB         0x1F

/* נתוני Quaternion WXYZ */                      // HE: פורמט יחידות לפי 1/2^14
#define BNO055_QUA_DATA_W_LSB        0x20
#define BNO055_QUA_DATA_W_MSB        0x21
#define BNO055_QUA_DATA_X_LSB        0x22
#define BNO055_QUA_DATA_X_MSB        0x23
#define BNO055_QUA_DATA_Y_LSB        0x24
#define BNO055_QUA_DATA_Y_MSB        0x25
#define BNO055_QUA_DATA_Z_LSB        0x26
#define BNO055_QUA_DATA_Z_MSB        0x27

/* Linear Acceleration vector */                  // HE: תאוצה ללא רכיב כבידה
#define BNO055_LIA_DATA_X_LSB        0x28
#define BNO055_LIA_DATA_X_MSB        0x29
#define BNO055_LIA_DATA_Y_LSB        0x2A
#define BNO055_LIA_DATA_Y_MSB        0x2B
#define BNO055_LIA_DATA_Z_LSB        0x2C
#define BNO055_LIA_DATA_Z_MSB        0x2D

/* Gravity vector */                               // HE: וקטור כבידה בלבד
#define BNO055_GRV_DATA_X_LSB        0x2E
#define BNO055_GRV_DATA_X_MSB        0x2F
#define BNO055_GRV_DATA_Y_LSB        0x30
#define BNO055_GRV_DATA_Y_MSB        0x31
#define BNO055_GRV_DATA_Z_LSB        0x32
#define BNO055_GRV_DATA_Z_MSB        0x33

/* טמפרטורה מצב וכיול */                         // HE: טמפרטורה סטטוסים וכיול
#define BNO055_TEMP                  0x34           // HE: טמפרטורה במעלות צלזיוס
#define BNO055_CALIB_STAT            0x35           // HE: מצב כיול מערכת וחיישנים
#define BNO055_ST_RESULT             0x36           // HE: Self test results
#define BNO055_SYS_STATUS            0x39           // HE: מצב מערכת
#define BNO055_SYS_ERR               0x3A           // HE: קוד שגיאה מערכת

/* הגדרות יחידות ומצב עבודה */                   // HE: יחידות ומצבי עבודה
#define BNO055_UNIT_SEL              0x3B
#define BNO055_OPR_MODE              0x3D           // HE: Operation mode
#define BNO055_PWR_MODE              0x3E           // HE: Power mode
#define BNO055_SYS_TRIGGER           0x3F           // HE: Reset, self test, חיצוני
#define BNO055_AXIS_MAP_CONFIG       0x41           // HE: Remap צירים
#define BNO055_AXIS_MAP_SIGN         0x42           // HE: סימן צירים

/* רגיסטרי כיול offset radius */                  // HE: אוף סט ורדיוסים
#define BNO055_ACC_OFFSET_X_LSB      0x55           // HE: מכאן מתחיל בלוק כיול של 22 בייט
#define BNO055_ACC_OFFSET_X_MSB      0x56
#define BNO055_ACC_OFFSET_Y_LSB      0x57
#define BNO055_ACC_OFFSET_Y_MSB      0x58
#define BNO055_ACC_OFFSET_Z_LSB      0x59
#define BNO055_ACC_OFFSET_Z_MSB      0x5A

#define BNO055_MAG_OFFSET_X_LSB      0x5B
#define BNO055_MAG_OFFSET_X_MSB      0x5C
#define BNO055_MAG_OFFSET_Y_LSB      0x5D
#define BNO055_MAG_OFFSET_Y_MSB      0x5E
#define BNO055_MAG_OFFSET_Z_LSB      0x5F
#define BNO055_MAG_OFFSET_Z_MSB      0x60

#define BNO055_GYR_OFFSET_X_LSB      0x61
#define BNO055_GYR_OFFSET_X_MSB      0x62
#define BNO055_GYR_OFFSET_Y_LSB      0x63
#define BNO055_GYR_OFFSET_Y_MSB      0x64
#define BNO055_GYR_OFFSET_Z_LSB      0x65
#define BNO055_GYR_OFFSET_Z_MSB      0x66

#define BNO055_ACC_RADIUS_LSB        0x67
#define BNO055_ACC_RADIUS_MSB        0x68
#define BNO055_MAG_RADIUS_LSB        0x69
#define BNO055_MAG_RADIUS_MSB        0x6A

/* קודי מצב מערכת SYS_STATUS לפי הדאטה שיט */    // HE: מה משמעות הערך של SYS_STATUS
#define BNO055_SYSTEM_STATUS_IDLE                     0x00  // HE: לא רץ אלגוריתם פיוז'ן
#define BNO055_SYSTEM_STATUS_SYSTEM_ERROR             0x01  // HE: יש שגיאת מערכת
#define BNO055_SYSTEM_STATUS_INITIALIZING_PERIPH      0x02  // HE: מאתחל פריפריות
#define BNO055_SYSTEM_STATUS_SYSTEM_INITIALIZING      0x03  // HE: מאתחל מערכת
#define BNO055_SYSTEM_STATUS_EXECUTING_SELFTEST       0x04  // HE: מריץ self test
#define BNO055_SYSTEM_STATUS_FUSION_ALGO_RUNNING      0x05  // HE: אלגוריתם פיוז'ן רץ תקין

/* enum: מצבי עבודה של BNO055 */                   // HE: OPR_MODE לערכים שונים
typedef enum
{
    BNO055_OPERATION_MODE_CONFIG        = 0x00,      // HE: מצב קונפיגורציה בלבד
    BNO055_OPERATION_MODE_ACCONLY       = 0x01,      // HE: אקסלרומטר בלבד
    BNO055_OPERATION_MODE_MAGONLY       = 0x02,      // HE: מגנטומטר בלבד
    BNO055_OPERATION_MODE_GYRONLY       = 0x03,      // HE: ג'ירו בלבד
    BNO055_OPERATION_MODE_ACCMAG        = 0x04,      // HE: אקסלרומטר ומגנטומטר
    BNO055_OPERATION_MODE_ACCGYRO       = 0x05,      // HE: אקסלרומטר וג'ירו
    BNO055_OPERATION_MODE_MAGGYRO       = 0x06,      // HE: מגנטומטר וג'ירו
    BNO055_OPERATION_MODE_AMG           = 0x07,      // HE: Accel Mag Gyro ללא פיוז'ן
    BNO055_OPERATION_MODE_IMUPLUS       = 0x08,      // HE: IMU plus
    BNO055_OPERATION_MODE_COMPASS       = 0x09,      // HE: מצפן
    BNO055_OPERATION_MODE_M4G           = 0x0A,      // HE: M4G
    BNO055_OPERATION_MODE_NDOF_FMC_OFF  = 0x0B,      // HE: NDOF ללא fast mag calibration
    BNO055_OPERATION_MODE_NDOF          = 0x0C       // HE: NDOF מלא פיוז'ן
} bno055_opmode_t;

/* מבנה וקטור כללי */                              // HE: משמש גם לאוילר גם לאקסלרומטר וכו
typedef struct
{
    double w;                                        // HE: רכיב W בקווטרניון או 0 עבור XYZ רגיל
    double x;                                        // HE: ציר X
    double y;                                        // HE: ציר Y
    double z;                                        // HE: ציר Z
} bno055_vector_t;

/* תוצאות self test */                             // HE: פירוק ביטים מ ST_RESULT
typedef struct
{
    uint8_t mcuState;                                // HE: בדיקת MCU
    uint8_t gyrState;                                // HE: בדיקת Gyro
    uint8_t magState;                                // HE: בדיקת Mag
    uint8_t accState;                                // HE: בדיקת Accel
} bno055_self_test_result_t;

/* מצב כיול */                                     // HE: רמת כיול 0 עד 3 לכל חלק
typedef struct
{
    uint8_t sys;                                     // HE: כיול מערכת כללית
    uint8_t gyro;                                    // HE: כיול Gyro
    uint8_t accel;                                   // HE: כיול Accel
    uint8_t mag;                                     // HE: כיול Mag
} bno055_calibration_state_t;

/* אוף סטים של צירים */                           // HE: אוף סט XYZ לכל חיישן
typedef struct
{
    int16_t x;                                       // HE: offset בציר X
    int16_t y;                                       // HE: offset בציר Y
    int16_t z;                                       // HE: offset בציר Z
} bno055_axis_offset3_t;

/* רדיוסי כיול */                                  // HE: רדיוס עבור accel ו mag
typedef struct
{
    int16_t accel;                                   // HE: רדיוס אקסלרומטר
    int16_t mag;                                     // HE: רדיוס מגנטומטר
} bno055_radius2_t;

/* מידע כיול מלא: offsets ורדיוסים */            // HE: מבנה ששומרים / טוענים בבלוק אחד
typedef struct
{
    struct {
        bno055_axis_offset3_t accel;                // HE: offset אקסלרומטר
        bno055_axis_offset3_t mag;                  // HE: offset מגנטומטר
        bno055_axis_offset3_t gyro;                 // HE: offset ג'ירו
    } offset;

    bno055_radius2_t radius;                        // HE: רדיוסים accel mag
} bno055_calibration_data_t;

/* מיפוי צירים למיקרו / כרטיס */                  // HE: מאפשר להגדיר איזה ציר של החיישן מתאים ל X Y Z שלנו
typedef struct
{
    uint8_t x;                                      // HE: איזה ציר פיזי של החיישן מחובר ל X של המערכת
    uint8_t y;                                      // HE: ציר עבור Y
    uint8_t z;                                      // HE: ציר עבור Z

    uint8_t x_sign;                                 // HE: סימן X 0 רגיל 1 הפוך
    uint8_t y_sign;                                 // HE: סימן Y
    uint8_t z_sign;                                 // HE: סימן Z
} bno055_axis_map_t;

/* --------------------------------------------------------------------- */
/* הצהרות פונקציה כפי שמשתמשים בקובץ BNO055.c                            */
/* --------------------------------------------------------------------- */

/* הגדרות בסיסיות ואתחול */                        // HE: פונקציות הגדרה
void bno055_setup(void);                            // HE: אתחול בסיסי אחרי reset
void bno055_reset(void);                            // HE: reset דרך SYS_TRIGGER

bno055_opmode_t bno055_getOperationMode(void);      // HE: קריאת מצב עבודה נוכחי
void bno055_setOperationMode(bno055_opmode_t mode); // HE: קביעת מצב עבודה
void bno055_setOperationModeConfig(void);           // HE: מעבר ל CONFIG
void bno055_setOperationModeNDOF(void);             // HE: מעבר ל NDOF פיוז'ן מלא

void bno055_enableExternalCrystal(void);            // HE: שימוש בקריסטל חיצוני
void bno055_disableExternalCrystal(void);           // HE: חזרה לאוסילטור פנימי

int8_t  bno055_getTemp(void);                       // HE: קריאת טמפרטורה
int16_t bno055_getSWRevision(void);                 // HE: גרסת תוכנה
uint8_t bno055_getBootloaderRevision(void);         // HE: גרסת bootloader

uint8_t bno055_getSystemStatus(void);               // HE: קריאת SYS_STATUS
uint8_t bno055_getSystemError(void);                // HE: קריאת SYS_ERR

bno055_self_test_result_t    bno055_getSelfTestResult(void);   // HE: תוצאת self test
bno055_calibration_state_t   bno055_getCalibrationState(void); // HE: מצב כיול
bno055_calibration_data_t    bno055_getCalibrationData(void);  // HE: קריאת נתוני כיול מלאים
void bno055_setCalibrationData(bno055_calibration_data_t cal); // HE: כתיבת נתוני כיול

/* וקטורים שונים */                               // HE: קריאת נתונים מהחיישן
bno055_vector_t bno055_getVectorEuler(void);        // HE: זוויות Heading Roll Pitch
bno055_vector_t bno055_getVectorQuaternion(void);   // HE: קווטרניון
bno055_vector_t bno055_getVectorAccelerometer(void);// HE: תאוצה
bno055_vector_t bno055_getVectorGyroscope(void);    // HE: ג'ירו
bno055_vector_t bno055_getVectorMagnetometer(void); // HE: מגנטומטר
bno055_vector_t bno055_getVectorLinearAccel(void);  // HE: תאוצה ליניארית
bno055_vector_t bno055_getVectorGravity(void);      // HE: וקטור כבידה

/* מיפוי צירים */                                 // HE: הגדרת כיוון חיישן על הכרטיס
void bno055_setAxisMap(bno055_axis_map_t axis);     // HE: הגדרת מיפוי צירים

/* פונקציות low level שממומשות ב BNO055.c */      // HE: עטיפה על HAL
void bno055_delay(int time_ms);                     // HE: דיליי במילישניות
void bno055_writeData(uint8_t reg, uint8_t data);   // HE: כתיבת רגיסטר
void bno055_readData(uint8_t reg, uint8_t *data,
                     uint8_t len);                  // HE: קריאת len בתים מרגיסטר

#endif /* INC_BNO055_H_ */
