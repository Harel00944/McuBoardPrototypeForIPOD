/* File: st7735.c                                   // Detailed driver for ST7735 TFT display
   Purpose: minimal functions to initialize the display and write "HAREL" in the center */

#include "st7735.h"// Include display header for pin definitions and function prototypes
#include <string.h>    // For strlen function, handles string length
#include <ctype.h>     // For character conversion like tolower



/* Helper macros for controlling pins: CS and DC and RES */

static void ST7735_Select(void)                    // Select the ST7735 display for SPI transfer by pulling CS low
{
    HAL_GPIO_WritePin(ST7735_CS_GPIO,              // Use HAL function to control the chip select GPIO port
                      ST7735_CS_PIN,               // Use the chip select pin that belongs to the display
                      GPIO_PIN_RESET);             // Drive CS low so the display listens to SPI transfers
}

static void ST7735_Unselect(void)                  // Unselect the display after SPI transfer by pulling CS high
{
    HAL_GPIO_WritePin(ST7735_CS_GPIO,              // Use HAL function to control the chip select GPIO port
                      ST7735_CS_PIN,               // Use the chip select pin that belongs to the display
                      GPIO_PIN_SET);               // Drive CS high so the display ignores further SPI transfers
}

static void ST7735_DC_Command(void)                // Put the display into "command" mode by changing DC line
{
    HAL_GPIO_WritePin(ST7735_DC_GPIO,              // Use HAL to drive the data-command GPIO port
                      ST7735_DC_PIN,               // Use the data-command pin of the display
                      GPIO_PIN_RESET);             // Drive DC low so the next SPI byte is interpreted as a command
}

static void ST7735_DC_Data(void)                   // Put the display into "data" mode by changing DC line
{
    HAL_GPIO_WritePin(ST7735_DC_GPIO,              // Use HAL to drive the data-command GPIO port
                      ST7735_DC_PIN,               // Use the data-command pin of the display
                      GPIO_PIN_SET);               // Drive DC high so the next SPI bytes are interpreted as pixel or parameter data
}


/* Optional reset function: generates a reset pulse on RES pin if it is connected */

static void ST7735_Reset(void)                     // Reset the display controller using the RES pin and delays
{
    HAL_GPIO_WritePin(ST7735_RES_GPIO,             // Use HAL to control the reset GPIO port
                      ST7735_RES_PIN,              // Use the reset pin of the display
                      GPIO_PIN_RESET);             // Drive RES low to force the display controller into reset state
    HAL_Delay(10);                                 // Wait 10 milliseconds so the reset pulse width is long enough
    HAL_GPIO_WritePin(ST7735_RES_GPIO,             // Use HAL to control the reset GPIO port again
                      ST7735_RES_PIN,              // Same reset pin
                      GPIO_PIN_SET);               // Release RES high so the controller exits reset and starts boot sequence
    HAL_Delay(120);                                // Wait 120 milliseconds to allow internal power on and oscillator stabilization
}


/* SPI send helpers: wrappers that handle CS and DC around HAL SPI transmit */

static void ST7735_WriteCommand(uint8_t cmd)       // Send a single command byte to the display over SPI
{
    ST7735_Select();                               // Assert CS low to select the display before transmitting
    ST7735_DC_Command();                           // Put DC into command mode so the byte is treated as a command
    HAL_SPI_Transmit(&hspi1,                       // Use SPI handle hspi1 that was configured in CubeMX
                     &cmd,                         // Pointer to the command byte in memory
                     1,                            // Transmit exactly one byte
                     HAL_MAX_DELAY);               // Block indefinitely until SPI transfer completes
    ST7735_Unselect();                             // Deassert CS high to finish the SPI transaction
}

static void ST7735_WriteData(uint8_t *data,        // Send a buffer of data bytes to the display
                             uint16_t size)        // Number of bytes to transmit from the buffer
{
    ST7735_Select();                               // Assert CS low so the display is selected
    ST7735_DC_Data();                              // Put DC into data mode so bytes are interpreted as data
    HAL_SPI_Transmit(&hspi1,                       // Use SPI handle hspi1
                     data,                         // Pointer to the data buffer that holds bytes to send
                     size,                         // Number of bytes to transmit from the buffer
                     HAL_MAX_DELAY);               // Wait as long as needed until the SPI transfer is finished
    ST7735_Unselect();                             // Deassert CS high to end communication with the display
}


/* Set drawing area window: define the rectangle in which pixel data will be written */

static void ST7735_SetAddressWindow(uint16_t x0,   // Left column of the window (start X coordinate)
                                    uint16_t y0,   // Top row of the window (start Y coordinate)
                                    uint16_t x1,   // Right column of the window (end X coordinate)
                                    uint16_t y1)   // Bottom row of the window (end Y coordinate)
{
    uint8_t data[4];                               // Temporary array for sending high and low bytes of start and end coordinates

    uint8_t cmd = 0x2A;                            // 0x2A is the ST7735 CASET command that sets column address range
    ST7735_WriteCommand(cmd);                      // Send CASET command to the display
    data[0] = 0x00;                                // High byte of starting column is zero because columns are 0..127
    data[1] = x0 & 0xFF;                           // Low byte of starting column is x0 masked to one byte
    data[2] = 0x00;                                // High byte of ending column is also zero
    data[3] = x1 & 0xFF;                           // Low byte of ending column is x1 masked to one byte
    ST7735_WriteData(data, 4);                     // Send 4 bytes to define the column range for drawing

    cmd = 0x2B;                                    // 0x2B is the ST7735 RASET command that sets row address range
    ST7735_WriteCommand(cmd);                      // Send RASET command to the display
    data[0] = 0x00;                                // High byte of starting row is zero because rows are 0..159
    data[1] = y0 & 0xFF;                           // Low byte of starting row is y0 masked to one byte
    data[2] = 0x00;                                // High byte of ending row is zero
    data[3] = y1 & 0xFF;                           // Low byte of ending row is y1 masked to one byte
    ST7735_WriteData(data, 4);                     // Send 4 bytes to define the row range for drawing

    cmd = 0x2C;                                    // 0x2C is the ST7735 RAMWR command to start memory write
    ST7735_WriteCommand(cmd);                      // Send RAMWR command so the next data bytes will be written as pixels
}


/* Draw single pixel at (x y) using RGB565 color value */

static void ST7735_DrawPixel(uint16_t x,           // X coordinate of the pixel to draw
                             uint16_t y,           // Y coordinate of the pixel to draw
                             uint16_t color)       // 16 bit RGB565 color that defines pixel color
{
    if (x >= ST7735_WIDTH ||                       // Check if X coordinate is outside the valid display width
        y >= ST7735_HEIGHT)                        // Or Y coordinate is outside the valid display height
    {
        return;                                    // If pixel is outside the screen boundaries, do nothing and exit
    }

    uint8_t data[2];                               // Two bytes are needed to represent one RGB565 color value
    ST7735_SetAddressWindow(x, y,                  // Set the drawing window to start at X and Y
                            x, y);                 // And end at the same X and Y so the window is a single pixel

    data[0] = color >> 8;                          // Extract high byte of the 16 bit color (most significant 8 bits)
    data[1] = color & 0xFF;                        // Extract low byte of the 16 bit color (least significant 8 bits)
    ST7735_WriteData(data, 2);                     // Send both bytes as pixel data to the display in RGB565 format
}




/* Display initialization sequence: program ST7735 registers to configure timing, power and color mode */

void ST7735_Init(void)                            // Public initialization function that main code calls once at startup
{
    ST7735_Unselect();                             // Ensure CS is high and display is not selected before starting configuration

    ST7735_Reset();                                // Generate a reset pulse to put the controller into a known state

    ST7735_WriteCommand(0x11);                     // Send "Sleep Out" command so the display exits sleep mode
    HAL_Delay(120);                                // Wait 120 milliseconds as specified in the ST7735 datasheet

    uint8_t data1[] = {0x01, 0x2C, 0x2D};         // Parameters for Frame Rate Control in normal mode
    uint8_t data2[] = {0x01, 0x2C, 0x2D};         // Parameters for Frame Rate Control in idle mode
    uint8_t data3[] = {0x01, 0x2C, 0x2D,          // Parameters for Frame Rate Control in partial mode
                       0x01, 0x2C, 0x2D};         // This array holds two triplets for different settings

    ST7735_WriteCommand(0xB1);                    // 0xB1 is Frame Rate Control command for normal mode
    ST7735_WriteData(data1, sizeof(data1));       // Send three bytes of frame rate parameters for normal mode

    ST7735_WriteCommand(0xB2);                    // 0xB2 is Frame Rate Control command for idle mode
    ST7735_WriteData(data2, sizeof(data2));       // Send three bytes of frame rate parameters for idle mode

    ST7735_WriteCommand(0xB3);                    // 0xB3 is Frame Rate Control command for partial mode
    ST7735_WriteData(data3, sizeof(data3));       // Send six bytes because partial mode uses two parameter sets

    uint8_t data_inv[] = {0x07};                  // Value that sets how inversion is applied for the display pixels
    ST7735_WriteCommand(0xB4);                    // 0xB4 is Display Inversion Control command
    ST7735_WriteData(data_inv, sizeof(data_inv)); // Send single inversion configuration byte

    uint8_t data_c0[] = {0xA2, 0x02, 0x84};       // Parameters for Power Control 1 (voltage and current settings)
    ST7735_WriteCommand(0xC0);                    // 0xC0 is Power Control 1 command
    ST7735_WriteData(data_c0, sizeof(data_c0));   // Send three bytes that tune internal power amplifier

    uint8_t data_c1[] = {0xC5};                   // Parameter for Power Control 2
    ST7735_WriteCommand(0xC1);                    // 0xC1 is Power Control 2 command
    ST7735_WriteData(data_c1, sizeof(data_c1));   // Send single byte that adjusts step up factor

    uint8_t data_c2[] = {0x0A, 0x00};             // Parameters for Power Control 3
    ST7735_WriteCommand(0xC2);                    // 0xC2 is Power Control 3 command
    ST7735_WriteData(data_c2, sizeof(data_c2));   // Send two bytes for op amp current and boosting

    uint8_t data_c3[] = {0x8A, 0x2A};             // Parameters for Power Control 4
    ST7735_WriteCommand(0xC3);                    // 0xC3 is Power Control 4 command
    ST7735_WriteData(data_c3, sizeof(data_c3));   // Send two bytes controlling VGH and VGL voltages

    uint8_t data_c4[] = {0x8A, 0xEE};             // Parameters for Power Control 5
    ST7735_WriteCommand(0xC4);                    // 0xC4 is Power Control 5 command
    ST7735_WriteData(data_c4, sizeof(data_c4));   // Send two bytes with further voltage tuning

    uint8_t data_vcom[] = {0x0E};                 // Value to configure VCOM voltage level
    ST7735_WriteCommand(0xC5);                    // 0xC5 is VCOM control command
    ST7735_WriteData(data_vcom, sizeof(data_vcom)); // Send single byte that affects contrast and flicker

    uint8_t data_mem[] = {0xC8};                  // Memory access control bitmask: defines orientation and RGB order
    ST7735_WriteCommand(0x36);                    // 0x36 is Memory Access Control command
    ST7735_WriteData(data_mem, sizeof(data_mem)); // Send one byte to set row/column order and refresh direction

    uint8_t data_colmod[] = {0x05};               // 0x05 selects 16 bits per pixel RGB565 color mode
    ST7735_WriteCommand(0x3A);                    // 0x3A is COLMOD (interface pixel format) command
    ST7735_WriteData(data_colmod, sizeof(data_colmod)); // Send one byte indicating pixel format

    uint8_t data_xrange[] = {0x00, 0x00,          // Start column high and low bytes (0)
                             0x00, 0x7F};         // End column high byte and low byte (0x7F = 127)
    ST7735_WriteCommand(0x2A);                    // CASET sets column address range again
    ST7735_WriteData(data_xrange, sizeof(data_xrange)); // Apply column range 0 to 127

    uint8_t data_yrange[] = {0x00, 0x00,          // Start row high and low bytes (0)
                             0x00, 0x9F};         // End row high byte and low byte (0x9F = 159)
    ST7735_WriteCommand(0x2B);                    // RASET sets row address range again
    ST7735_WriteData(data_yrange, sizeof(data_yrange)); // Apply row range 0 to 159

    ST7735_WriteCommand(0x13);                    // 0x13 sets Normal Display Mode on
    HAL_Delay(10);                                // Short delay to allow mode change to settle

    ST7735_WriteCommand(0x29);                    // 0x29 is Display ON command so backlight appears with valid content
    HAL_Delay(100);                               // Wait 100 milliseconds for full display stabilization
}


/* Fill entire screen with a single RGB565 color */

void ST7735_FillScreen(uint16_t color)            // Public function to clear the screen or set a background color
{
    uint8_t data[2];                              // Temporary buffer to hold high and low bytes of the color
    data[0] = color >> 8;                         // Store high byte of the 16 bit color in the first array element
    data[1] = color & 0xFF;                       // Store low byte of the 16 bit color in the second array element

    ST7735_SetAddressWindow(0, 0,                 // Set start column to 0 and start row to 0
                            ST7735_WIDTH - 1,     // Set end column to last valid column index
                            ST7735_HEIGHT - 1);   // Set end row to last valid row index so window covers whole screen

    ST7735_Select();                              // Select the display by pulling CS low
    ST7735_DC_Data();                             // Put DC in data mode because we are sending pixel data now

    for (uint32_t i = 0;                          // Initialize loop counter to zero
         i < ST7735_WIDTH * ST7735_HEIGHT;        // Loop while i is less than total number of pixels
         i++)                                     // Increment loop counter by one for each pixel
    {
        HAL_SPI_Transmit(&hspi1,                  // Use SPI1 peripheral to send data
                         data,                    // Pointer to the two-byte color buffer
                         2,                       // Send exactly two bytes for each pixel (one RGB565 color)
                         HAL_MAX_DELAY);          // Wait for the transmission to complete without timeout
    }

    ST7735_Unselect();                            // Unselect the display after writing all pixels
}


/* Simple 5x7 font definition for letters H A R E L */

/* Structure used to describe a 5x7 letter bitmap */

typedef struct
{
    uint8_t rows[7];   // Each entry represents one horizontal row of the 5x7 character. Only the lowest 5 bits are used.
} Letter5x7;

/* ============================================================
   LOWERCASE LETTERS FONT (a-z) IN 5x7 FORMAT
   Each byte uses bits 4..0 to represent 5 pixels:
   bit4: leftmost pixel, bit0: rightmost pixel in the row.
   ============================================================ */

/* Lowercase 'a' */
static const Letter5x7 LETTER_a =
{
    {0x0E, 0x01, 0x0F, 0x11, 0x0F, 0x00, 0x00}  // Simple rounded 'a' shape
};

/* Lowercase 'b' */
static const Letter5x7 LETTER_b =
{
    {0x10, 0x10, 0x1E, 0x11, 0x1E, 0x00, 0x00}  // Vertical left bar with rounded right side
};

/* Lowercase 'c' */
static const Letter5x7 LETTER_c =
{
    {0x0E, 0x11, 0x10, 0x10, 0x0E, 0x00, 0x00}  // Open circle on the right side
};

/* Lowercase 'd' */
static const Letter5x7 LETTER_d =
{
    {0x01, 0x01, 0x0F, 0x11, 0x0F, 0x00, 0x00}  // Mirror shape of 'b' on the right
};

/* Lowercase 'e' */
static const Letter5x7 LETTER_e =
{
    {0x0E, 0x11, 0x1F, 0x10, 0x0E, 0x00, 0x00}  // 'e' with horizontal bar in the middle
};

/* Lowercase 'f' */
static const Letter5x7 LETTER_f =
{
    {0x07, 0x08, 0x1E, 0x08, 0x08, 0x00, 0x00}  // Tall 'f' with top bar and vertical stem
};

/* Lowercase 'g' */
static const Letter5x7 LETTER_g =
{
    {0x0F, 0x11, 0x11, 0x0F, 0x01, 0x0E, 0x00}  // 'g' with closed loop and small tail
};

/* Lowercase 'h' */
static const Letter5x7 LETTER_h =
{
    {0x10, 0x10, 0x1E, 0x11, 0x11, 0x11, 0x00}  // Left stem with right rounded part
};

/* Lowercase 'i' */
static const Letter5x7 LETTER_i =
{
    {0x04, 0x00, 0x0C, 0x04, 0x0E, 0x00, 0x00}  // Dot on top, short body
};

/* Lowercase 'j' */
static const Letter5x7 LETTER_j =
{
    {0x02, 0x00, 0x06, 0x02, 0x12, 0x0C, 0x00}  // Small 'j' with descender
};

/* Lowercase 'k' */
static const Letter5x7 LETTER_k =
{
    {0x10, 0x10, 0x14, 0x18, 0x14, 0x00, 0x00}  // Left stem with angled arm
};

/* Lowercase 'l' */
static const Letter5x7 LETTER_l =
{
    {0x0C, 0x04, 0x04, 0x04, 0x0E, 0x00, 0x00}  // Tall narrow 'l'
};

/* Lowercase 'm' */
static const Letter5x7 LETTER_m =
{
    {0x00, 0x00, 0x1A, 0x15, 0x15, 0x00, 0x00}  // Two bumps for 'm'
};

/* Lowercase 'n' */
static const Letter5x7 LETTER_n =
{
    {0x00, 0x00, 0x1E, 0x11, 0x11, 0x00, 0x00}  // Similar to 'h' but shorter
};

/* Lowercase 'o' */
static const Letter5x7 LETTER_o =
{
    {0x00, 0x00, 0x0E, 0x11, 0x0E, 0x00, 0x00}  // Small circle 'o'
};

/* Lowercase 'p' */
static const Letter5x7 LETTER_p =
{
    {0x00, 0x00, 0x1E, 0x11, 0x1E, 0x10, 0x10}  // 'p' with descending vertical bar
};

/* Lowercase 'q' */
static const Letter5x7 LETTER_q =
{
    {0x00, 0x00, 0x0F, 0x11, 0x0F, 0x01, 0x01}  // 'q' mirrored 'p' descending to the right
};

/* Lowercase 'r' */
static const Letter5x7 LETTER_r =
{
    {0x00, 0x1E, 0x11, 0x10, 0x10, 0x00, 0x00}  // Short 'r' with a small arm
};

/* Lowercase 's' */
static const Letter5x7 LETTER_s =
{
    {0x00, 0x00, 0x0F, 0x10, 0x1E, 0x00, 0x00}  // Curved small 's'
};

/* Lowercase 't' */

static const Letter5x7 LETTER_t =
{
    {0x08, 0x08, 0x1E, 0x08, 0x06, 0x00, 0x00}  // 't' with top bar and short bottom
};

/* Lowercase 'u' */
static const Letter5x7 LETTER_u =
{
    {0x00, 0x00, 0x11, 0x11, 0x0F, 0x00, 0x00}  // Open at top, closed at bottom
};

/* Lowercase 'v' */
static const Letter5x7 LETTER_v =
{
    {0x00, 0x00, 0x11, 0x0A, 0x04, 0x00, 0x00}  // 'v' with pointed bottom
};

/* Lowercase 'w' */
static const Letter5x7 LETTER_w =
{
    {0x00, 0x00, 0x11, 0x15, 0x0A, 0x00, 0x00}  // 'w' with two dips
};

/* Lowercase 'x' */
static const Letter5x7 LETTER_x =
{
    {0x00, 0x00, 0x11, 0x0A, 0x11, 0x00, 0x00}  // Crossed shape for 'x'
};

/* Lowercase 'y' */
static const Letter5x7 LETTER_y =
{
    {0x00, 0x00, 0x11, 0x11, 0x0F, 0x01, 0x0E}  // 'y' with descending tail
};

/* Lowercase 'z' */
static const Letter5x7 LETTER_z =
{
    {0x00, 0x00, 0x1F, 0x02, 0x1F, 0x00, 0x00}  // Slanted 'z' with top and bottom bars
};

/* Space character ' ' (draws an empty 5x7 block) */
static const Letter5x7 LETTER_space =
{
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}  // All rows off: full blank character
};


static const Letter5x7* ST7735_GetLetter5x7(char c)
{
    switch (c)
    {
        case 'a': return &LETTER_a;
        case 'b': return &LETTER_b;
        case 'c': return &LETTER_c;
        case 'd': return &LETTER_d;
        case 'e': return &LETTER_e;
        case 'f': return &LETTER_f;
        case 'g': return &LETTER_g;
        case 'h': return &LETTER_h;
        case 'i': return &LETTER_i;
        case 'j': return &LETTER_j;
        case 'k': return &LETTER_k;
        case 'l': return &LETTER_l;
        case 'm': return &LETTER_m;
        case 'n': return &LETTER_n;
        case 'o': return &LETTER_o;
        case 'p': return &LETTER_p;
        case 'q': return &LETTER_q;
        case 'r': return &LETTER_r;
        case 's': return &LETTER_s;
        case 't': return &LETTER_t;
        case 'u': return &LETTER_u;
        case 'v': return &LETTER_v;
        case 'w': return &LETTER_w;
        case 'x': return &LETTER_x;
        case 'y': return &LETTER_y;
        case 'z': return &LETTER_z;

        case ' ': return &LETTER_space;   // Space character

        default:  return &LETTER_space;   // Unknown characters are rendered as blank
    }
}



/* ============================================================
   PROTOTYPE: EXISTING PIXEL-LEVEL DRAWING FUNCTION
   (Already exists earlier in st7735.c)
   ============================================================ */

static void ST7735_DrawLetter(const Letter5x7 *letter, // Pointer to the bitmap definition of the letter to draw
                              uint16_t x,              // X coordinate of the top left corner where the letter begins
                              uint16_t y,              // Y coordinate of the top left corner where the letter begins
                              uint16_t fg,             // RGB565 color used for pixels that belong to the character (foreground)
                              uint16_t bg)             // RGB565 color used for pixels that are background
{
    for (uint8_t row = 0; row < 7; row++)        // Iterate from row index 0 to 6 over the seven rows of the letter
    {
        uint8_t bits = letter->rows[row];        // Load the row bitmask for the current row from the letter structure

        for (uint8_t col = 0; col < 5; col++)    // Iterate from column index 0 to 4 over the five columns of the letter
        {
            uint16_t color =                     // Decide which color to draw at this specific (row, col)
                (bits & (1U << (4 - col)))       // Check bit position corresponding to this column starting from bit4
                ? fg                             // If the bit is set, this pixel is part of the letter so use foreground color
                : bg;                            // If the bit is cleared, this pixel is background so use background color

            ST7735_DrawPixel(x + col,           // Draw pixel at X offset plus column index
                             y + row,           // Draw pixel at Y offset plus row index
                             color);            // Use computed color for this pixel
        }
    }
}

void ST7735_DrawChar5x7(char c,
                        uint16_t x,
                        uint16_t y,
                        uint16_t fg,
                        uint16_t bg)
{
    /* Find the bitmap corresponding to the ASCII character */
    const Letter5x7 *letter = ST7735_GetLetter5x7(c);

    /* Draw it using the existing 5x7 pixel-renderer */
    ST7735_DrawLetter(letter, x, y, fg, bg);
}

/* ============================================================
   PUBLIC: Draw 5x7 Text (string)
   ============================================================ */
void ST7735_DrawText5x7(const char *text,
                        uint16_t x,
                        uint16_t y,
                        uint16_t fg,
                        uint16_t bg)
{
    uint16_t cursor_x = x;     // Tracks X position while printing characters

    while (*text != '\0')      // Continue until string terminator '\0'
    {
        ST7735_DrawChar5x7(*text, cursor_x, y, fg, bg);

        cursor_x += 6;         // Move cursor: 5 pixels width + 1 pixel spacing
        text++;                // Advance to next character
    }
}


/* Draw the word "HAREL" roughly in the center of the display */

void ST7735_ShowHarel(void)                      // Public helper function called from main to display the text "HAREL"
{
    uint16_t fg = ST7735_COLOR_WHITE;            // Set foreground color to white so letters appear bright
    uint16_t bg = ST7735_COLOR_BLACK;            // Set background color to black so letters have strong contrast

    uint16_t text_width = 5 * 5 + 4 * 2;       // Precomputed width value used in this example for centering logic
    uint16_t start_x =                           // Compute starting X position so text is centered horizontally
        (ST7735_WIDTH - text_width) / 2;         // Subtract text width from screen width and divide by two to center

    uint16_t start_y =                           // Compute starting Y position so text is vertically centered for 7 pixel height
        (ST7735_HEIGHT - 7) / 2;                 // Subtract font height 7 from screen height and divide by two

    uint16_t x = start_x;                        // Initialize current drawing X position to the computed start_x

    ST7735_DrawLetter(&LETTER_h,                 // Draw letter H using its bitmap pattern
                      x,                         // Use current X position for the letter
                      start_y,                   // Use common Y starting coordinate for all letters
                      fg,                        // Foreground color for active pixels
                      bg);                       // Background color for inactive pixels

    x += 6;                                      // Move X position 6 pixels to the right (5 pixels letter width plus 1 pixel space)

    ST7735_DrawLetter(&LETTER_a,                 // Draw letter A
                      x,
                      start_y,
                      fg,
                      bg);

    x += 6;                                      // Move X position again for next letter

    ST7735_DrawLetter(&LETTER_r,                 // Draw letter R
                      x,
                      start_y,
                      fg,
                      bg);

    x += 6;                                      // Move X position again

    ST7735_DrawLetter(&LETTER_e,                 // Draw letter E
                      x,
                      start_y,
                      fg,
                      bg);

    x += 6;                                      // Move X position for final letter

    ST7735_DrawLetter(&LETTER_l,                 // Draw letter L
                      x,
                      start_y,
                      fg,
                      bg);
}





/* ============================================================
   PUBLIC: Show a sentence centered on the screen
   This function:
   1: Copies the input text into a local buffer
   2: Converts uppercase letters A..Z to lowercase a..z
   3: Calculates text width in pixels
   4: Centers the text horizontally and vertically
   5: Clears the screen and draws the text
   ============================================================ */

void ST7735_ShowSentenceCenter(const char *text)   // Public function that draws a full sentence in the center of the display
{
    char buffer[32];                               // Local buffer that holds a safe copy of the text for drawing
                                                   // 32 characters are enough because the screen can only show about 21 chars in one line: 128 / 6

    uint16_t maxChars = sizeof(buffer) - 1;        // Maximum number of characters we can store, minus one for the null terminator '\0'
    uint16_t len = strlen(text);                   // Measure how many characters are in the input string

    if (len > maxChars)                            // If the input string is longer than our buffer
    {
        len = maxChars;                            // Limit length so we do not write outside the buffer
    }

    /* Copy and normalize characters into buffer */
    for (uint16_t i = 0; i < len; i++)             // Loop over each character we decided to use
    {
        char c = text[i];                          // Read the original character from the input string

        if (c >= 'A' && c <= 'Z')                  // If character is uppercase letter between 'A' and 'Z'
        {
            c = (char)(c + ('a' - 'A'));           // Convert it to lowercase by adding the difference between 'a' and 'A'
        }

        buffer[i] = c;                             // Store the possibly converted character into our local buffer
    }

    buffer[len] = '\0';                            // Add string terminator so buffer becomes a valid C string

    /* Calculate text width in pixels
       Each character uses 5 pixels plus 1 pixel spacing so total is 6 pixels per character */
    uint16_t textWidth = len * 6;                  // Compute approximate width in pixels for the entire sentence

    uint16_t startX = 0;                           // X position where we start drawing the sentence

    if (textWidth < ST7735_WIDTH)                  // If the text width is smaller than the display width
    {
        startX = (ST7735_WIDTH - textWidth) / 2;   // Center text horizontally by calculating left margin
    }
    else                                           // Text is too wide or exactly equal to screen width
    {
        startX = 0;                                // Start from the left edge, text may be clipped on the right side
    }

    /* Vertical centering
       Our font is 7 pixels high */
    uint16_t startY = (ST7735_HEIGHT - 7) / 2;     // Center text vertically based on font height

    /* Choose colors for foreground and background */
    uint16_t fg = ST7735_COLOR_WHITE;              // Foreground color, white text
    uint16_t bg = ST7735_COLOR_BLACK;              // Background color, black screen

    /* Clear screen with background color before drawing */
    ST7735_FillScreen(bg);                         // Fill all pixels with black so old content disappears

    /* Draw the sentence using the existing 5x7 text drawing function */
    ST7735_DrawText5x7(buffer,                     // Use our normalized buffer as the text
                       startX,                     // Start position X, already centered
                       startY,                     // Start position Y, already centered
                       fg,                         // Foreground color for letters
                       bg);                        // Background color for empty pixels
}




/* ============================================================
   PUBLIC: Draw a sentence at a given position (x, y)
   This function:
   1: Copies the input text into a local buffer
   2: Converts uppercase letters A..Z to lowercase a..z
      because the 5x7 font is defined only for lowercase
   3: Calls ST7735_DrawText5x7 to draw the text at (x, y)
   It does not clear the screen
   ============================================================ */
void ST7735_ShowSentenceAt(const char *text,      // Text string that will be drawn on the display
                           uint16_t x,            // X coordinate of the starting position in pixels
                           uint16_t y,            // Y coordinate of the starting position in pixels
                           uint16_t fg,           // RGB565 color for the text (foreground)
                           uint16_t bg)           // RGB565 color for the background pixels inside each character
{
    char buffer[32];                              // Local buffer to hold a safe copy of the sentence
                                                  // 32 characters are enough for one line on a 128 pixel wide display

    uint16_t maxChars = sizeof(buffer) - 1;       // Maximum characters we can store, minus one for the null terminator
    uint16_t len = strlen(text);                  // Measure length of the input C string

    if (len > maxChars)                           // If input string is longer than buffer capacity
    {
        len = maxChars;                           // Limit the length, avoid writing outside buffer
    }

    /* Copy and normalize characters into buffer */
    for (uint16_t i = 0; i < len; i++)            // Loop through all characters that will be used
    {
        char c = text[i];                         // Read one character from the source string

        if (c >= 'A' && c <= 'Z')                 // If the character is uppercase A..Z
        {
            c = (char)(c + ('a' - 'A'));          // Convert it to lowercase by adding ASCII offset
        }

        buffer[i] = c;                            // Store the normalized character in our local buffer
    }

    buffer[len] = '\0';                           // Add string terminator so buffer becomes a valid C string

    /* Draw the sentence using the existing 5x7 text drawing function */
    ST7735_DrawText5x7(buffer,                    // Pointer to normalized text
                       x,                         // X coordinate where the text starts
                       y,                         // Y coordinate where the text starts
                       fg,                        // Foreground color, used for active character pixels
                       bg);                       // Background color, used for pixels inside character cell that are off
}

