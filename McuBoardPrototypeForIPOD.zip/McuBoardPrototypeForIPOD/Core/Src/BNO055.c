/* File: bno055.c */                                  // EN: Implementation of BNO055 driver for STM32

#include "BNO055.h"      // HE: אותו שם קובץ כמו ב main.c
#include "main.h"                                     // EN: For I2C handle hi2c1
#include "usbd_cdc_if.h"                              // EN: For USB_Printf debug output
#include <string.h>                                   // EN: For memcpy

/* Pointer to active I2C peripheral */                // EN: We use I2C1 from main.c
extern I2C_HandleTypeDef hi2c1;                       // EN: I2C1 handle defined in main.c
static I2C_HandleTypeDef *bno_i2c = &hi2c1;           // EN: Internal pointer to I2C used by driver

/* Scaling factors according to datasheet */          // EN: Convert raw LSB to physical units
static const double accelScale       = 100.0;         // EN: 1 LSB = 1/100 m/s^2
static const double tempScale        = 1.0;           // EN: 1 LSB = 1 deg C (not heavily used)
static const double angularRateScale = 16.0;          // EN: 1 LSB = 1/16 deg/s
static const double eulerScale       = 16.0;          // EN: 1 LSB = 1/16 degree
static const double magScale         = 16.0;          // EN: 1 LSB = 1/16 uT
static const double quaScale         = (1 << 14);     // EN: 1 LSB = 1/2^14 for quaternion

/* Local helper: select register page */              // EN: BNO055 has page 0 and 1
static void bno055_setPage(uint8_t page)
{
    bno055_writeData(BNO055_PAGE_ID, page);           // EN: Write desired page to PAGE_ID
}

/* Get current operation mode */                      // EN: Reads OPR_MODE register
bno055_opmode_t bno055_getOperationMode(void)
{
    uint8_t mode = 0;                                 // EN: Temporary storage for mode
    bno055_setPage(0);                                // EN: Ensure page 0 is selected
    bno055_readData(BNO055_OPR_MODE, &mode, 1);       // EN: Read one byte from OPR_MODE
    return (bno055_opmode_t)mode;                     // EN: Cast byte to enum and return
}

/* Set operation mode with correct delays */          // EN: Writes OPR_MODE and waits
void bno055_setOperationMode(bno055_opmode_t mode)
{
    bno055_setPage(0);                                // EN: Work on page 0
    bno055_writeData(BNO055_OPR_MODE, (uint8_t)mode); // EN: Write new mode

    if (mode == BNO055_OPERATION_MODE_CONFIG)         // EN: If switching to CONFIG mode
    {
        bno055_delay(19);                             // EN: Datasheet: min 19 ms
    }
    else                                              // EN: For all sensor or fusion modes
    {
        bno055_delay(7);                              // EN: Datasheet: min 7 ms
    }
}

/* Helper: go to CONFIG mode */                       // EN: Convenience wrapper
void bno055_setOperationModeConfig(void)
{
    bno055_setOperationMode(BNO055_OPERATION_MODE_CONFIG); // EN: Use generic setter
}

/* Helper: go to NDOF mode */                         // EN: Full fusion operation
void bno055_setOperationModeNDOF(void)
{
    bno055_setOperationMode(BNO055_OPERATION_MODE_NDOF);   // EN: Use generic setter
}

/* Internal: enable or disable external crystal */    // EN: Control EXT crystal bit
static void bno055_setExternalCrystalUse(bool state)
{
    uint8_t tmp = 0;                                  // EN: Temporary for SYS_TRIGGER

    bno055_setPage(0);                                // EN: Page 0
    bno055_readData(BNO055_SYS_TRIGGER, &tmp, 1);     // EN: Read current SYS_TRIGGER

    if (state)                                        // EN: If enabling external crystal
    {
        tmp |= 0x80;                                  // EN: Set bit 7
    }
    else                                              // EN: Disabling external crystal
    {
        tmp &= (uint8_t)(~0x80);                      // EN: Clear bit 7
    }

    bno055_writeData(BNO055_SYS_TRIGGER, tmp);        // EN: Write back modified value
    bno055_delay(700);                                // EN: Wait for oscillator to stabilize
}

/* Public wrappers for crystal control */             // EN: Simple user functions
void bno055_enableExternalCrystal(void)
{
    bno055_setExternalCrystalUse(true);               // EN: Enable external crystal
}

void bno055_disableExternalCrystal(void)
{
    bno055_setExternalCrystalUse(false);              // EN: Use internal oscillator
}

/* Reset device using SYS_TRIGGER */                  // EN: Software reset command
void bno055_reset(void)
{
    bno055_setPage(0);                                // EN: Use page 0
    bno055_writeData(BNO055_SYS_TRIGGER, 0x20);       // EN: Set RST_SYS bit
    bno055_delay(700);                                // EN: Wait for complete reboot
}

/* Read temperature in degrees Celsius */             // EN: Simple TEMP register read
int8_t bno055_getTemp(void)
{
    uint8_t t = 0;                                    // EN: Raw temp value
    bno055_setPage(0);                                // EN: Page 0
    bno055_readData(BNO055_TEMP, &t, 1);              // EN: Read TEMP register
    (void)tempScale;                                  // EN: Avoid unused warning
    return (int8_t)t;                                 // EN: Cast to signed 8 bit
}

/* Basic setup sequence */                            // EN: Called once after power up
void bno055_setup(void)
{
    uint8_t id = 0;                                   // EN: To verify CHIP_ID

    bno055_reset();                                   // EN: Perform soft reset

    bno055_setPage(0);                                // EN: Select page 0
    bno055_readData(BNO055_CHIP_ID, &id, 1);          // EN: Read CHIP_ID register

    /* No printf here, application can print id */    // EN: Keep driver generic

    bno055_writeData(BNO055_SYS_TRIGGER, 0x00);       // EN: Clear SYS_TRIGGER flags

    bno055_setOperationModeConfig();                  // EN: Ensure we are in CONFIG mode
    bno055_delay(10);                                 // EN: Small extra delay
}

/* Read software revision from two bytes */           // EN: SW_REV_ID_LSB and MSB
int16_t bno055_getSWRevision(void)
{
    uint8_t buffer[2] = {0};                          // EN: Two bytes buffer

    bno055_setPage(0);                                // EN: Page 0
    bno055_readData(BNO055_SW_REV_ID_LSB, buffer, 2); // EN: Read LSB and MSB

    int16_t rev = (int16_t)((buffer[1] << 8) | buffer[0]); // EN: Combine bytes
    return rev;                                       // EN: Return 16 bit revision
}

/* Bootloader revision */                             // EN: Simple one byte read
uint8_t bno055_getBootloaderRevision(void)
{
    uint8_t tmp = 0;                                  // EN: Temporary
    bno055_setPage(0);                                // EN: Page 0
    bno055_readData(BNO055_BL_REV_ID, &tmp, 1);       // EN: Read BL_REV_ID
    return tmp;                                       // EN: Return value
}

/* System status */                                   // EN: See datasheet for codes
uint8_t bno055_getSystemStatus(void)
{
    uint8_t tmp = 0;                                  // EN: Temporary
    bno055_setPage(0);                                // EN: Page 0
    bno055_readData(BNO055_SYS_STATUS, &tmp, 1);      // EN: Read SYS_STATUS
    return tmp;                                       // EN: Return status code
}

/* System error code */                               // EN: Detailed error if status shows error
uint8_t bno055_getSystemError(void)
{
    uint8_t tmp = 0;                                  // EN: Temporary
    bno055_setPage(0);                                // EN: Page 0
    bno055_readData(BNO055_SYS_ERR, &tmp, 1);         // EN: Read SYS_ERR
    return tmp;                                       // EN: Return error code
}

/* Self test result bits */                           // EN: Decode ST_RESULT register
bno055_self_test_result_t bno055_getSelfTestResult(void)
{
    uint8_t tmp = 0;                                  // EN: Raw ST_RESULT byte
    bno055_self_test_result_t res;                    // EN: Structure for results

    bno055_setPage(0);                                // EN: Page 0
    bno055_readData(BNO055_ST_RESULT, &tmp, 1);       // EN: Read one byte

    res.mcuState = (tmp >> 3) & 0x01;                 // EN: Bit 3 is MCU self test
    res.gyrState = (tmp >> 2) & 0x01;                 // EN: Bit 2 is gyro self test
    res.magState = (tmp >> 1) & 0x01;                 // EN: Bit 1 is mag self test
    res.accState = (tmp >> 0) & 0x01;                 // EN: Bit 0 is accel self test

    return res;                                       // EN: Return decoded structure
}

/* Calibration status flags */                        // EN: Decode CALIB_STAT register
bno055_calibration_state_t bno055_getCalibrationState(void)
{
    uint8_t calState = 0;                             // EN: Raw calibration bits
    bno055_calibration_state_t cal;                   // EN: Return structure

    bno055_setPage(0);                                // EN: Page 0
    bno055_readData(BNO055_CALIB_STAT, &calState, 1); // EN: Read CALIB_STAT

    cal.sys   = (calState >> 6) & 0x03;               // EN: Bits 7..6 - system
    cal.gyro  = (calState >> 4) & 0x03;               // EN: Bits 5..4 - gyro
    cal.accel = (calState >> 2) & 0x03;               // EN: Bits 3..2 - accel
    cal.mag   = (calState >> 0) & 0x03;               // EN: Bits 1..0 - mag

    return cal;                                       // EN: Return structure
}

/* Read calibration data block */                     // EN: Offsets and radii
bno055_calibration_data_t bno055_getCalibrationData(void)
{
    bno055_calibration_data_t calData;                // EN: Result structure
    uint8_t buffer[22];                               // EN: Raw 22 bytes
    bno055_opmode_t mode = bno055_getOperationMode(); // EN: Store current mode

    bno055_setOperationModeConfig();                  // EN: Enter CONFIG mode
    bno055_setPage(0);                                // EN: Page 0

    bno055_readData(BNO055_ACC_OFFSET_X_LSB, buffer, 22); // EN: Read block from ACC_OFFSET_X

    memcpy(&calData.offset.accel, buffer, 6);         // EN: Accel offsets
    memcpy(&calData.offset.mag,   buffer + 6, 6);     // EN: Mag offsets
    memcpy(&calData.offset.gyro,  buffer + 12, 6);    // EN: Gyro offsets
    memcpy(&calData.radius.accel, buffer + 18, 2);    // EN: Accel radius
    memcpy(&calData.radius.mag,   buffer + 20, 2);    // EN: Mag radius

    bno055_setOperationMode(mode);                    // EN: Restore previous mode

    return calData;                                   // EN: Return full structure
}

/* Program calibration data block */                  // EN: Write offsets and radii
void bno055_setCalibrationData(bno055_calibration_data_t calData)
{
    uint8_t buffer[22];                               // EN: Temporary array
    bno055_opmode_t mode = bno055_getOperationMode(); // EN: Save current mode

    bno055_setOperationModeConfig();                  // EN: Enter CONFIG mode
    bno055_setPage(0);                                // EN: Page 0

    memcpy(buffer,       &calData.offset.accel, 6);   // EN: Accel offsets
    memcpy(buffer + 6,   &calData.offset.mag,   6);   // EN: Mag offsets
    memcpy(buffer + 12,  &calData.offset.gyro,  6);   // EN: Gyro offsets
    memcpy(buffer + 18,  &calData.radius.accel, 2);   // EN: Accel radius
    memcpy(buffer + 20,  &calData.radius.mag,   2);   // EN: Mag radius

    for (uint8_t i = 0; i < 22; i++)                 // EN: Write all bytes one by one
    {
        bno055_writeData(BNO055_ACC_OFFSET_X_LSB + i, buffer[i]); // EN: Single byte write
    }

    bno055_setOperationMode(mode);                    // EN: Restore previous operation mode
}

/* Internal: read vector helper */                    // EN: Shared code for sensors and Euler
static bno055_vector_t bno055_getVectorInternal(uint8_t start_reg, bool is_quaternion)
{
    uint8_t buffer[8] = {0};                          // EN: Up to 8 bytes for quaternion
    double scale = 1.0;                               // EN: Scale factor
    bno055_vector_t v;                                // EN: Result vector

    v.w = v.x = v.y = v.z = 0.0;                      // EN: Initialize components

    bno055_setPage(0);                                // EN: Use page 0

    if (is_quaternion)                                // EN: Quaternion is 4 values
    {
        bno055_readData(start_reg, buffer, 8);        // EN: Read 8 bytes
        scale = quaScale;                             // EN: Use quaternion scale
    }
    else                                              // EN: Normal 3D vector
    {
        bno055_readData(start_reg, buffer, 6);        // EN: Read 6 bytes

        if (start_reg == BNO055_EUL_HEADING_LSB)      // EN: Euler angles vector
        {
            scale = eulerScale;                       // EN: Use Euler scaling
        }
        else if (start_reg == BNO055_ACC_DATA_X_LSB)  // EN: Accelerometer vector
        {
            scale = accelScale;                       // EN: Use accel scaling
        }
        else if (start_reg == BNO055_GYR_DATA_X_LSB)  // EN: Gyro vector
        {
            scale = angularRateScale;                 // EN: Use gyro scaling
        }
        else if (start_reg == BNO055_MAG_DATA_X_LSB)  // EN: Magnetometer vector
        {
            scale = magScale;                         // EN: Use mag scaling
        }
        else                                          // EN: Other vectors reuse accel scale
        {
            scale = accelScale;                       // EN: Default scaling
        }
    }

    if (is_quaternion)                                // EN: Decode WXYZ
    {
        int16_t w = (int16_t)((buffer[1] << 8) | buffer[0]); // EN: W raw
        int16_t x = (int16_t)((buffer[3] << 8) | buffer[2]); // EN: X raw
        int16_t y = (int16_t)((buffer[5] << 8) | buffer[4]); // EN: Y raw
        int16_t z = (int16_t)((buffer[7] << 8) | buffer[6]); // EN: Z raw

        v.w = (double)w / scale;                     // EN: Convert to double
        v.x = (double)x / scale;                     // EN: Convert to double
        v.y = (double)y / scale;                     // EN: Convert to double
        v.z = (double)z / scale;                     // EN: Convert to double
    }
    else                                              // EN: Decode XYZ
    {
        int16_t x = (int16_t)((buffer[1] << 8) | buffer[0]); // EN: X raw
        int16_t y = (int16_t)((buffer[3] << 8) | buffer[2]); // EN: Y raw
        int16_t z = (int16_t)((buffer[5] << 8) | buffer[4]); // EN: Z raw

        v.x = (double)x / scale;                     // EN: Convert to double
        v.y = (double)y / scale;                     // EN: Convert to double
        v.z = (double)z / scale;                     // EN: Convert to double
    }

    return v;                                        // EN: Return final vector
}

/* Public vector wrappers */                         // EN: User friendly functions

bno055_vector_t bno055_getVectorEuler(void)
{
    return bno055_getVectorInternal(BNO055_EUL_HEADING_LSB, false); // EN: Heading, roll, pitch
}

bno055_vector_t bno055_getVectorQuaternion(void)
{
    return bno055_getVectorInternal(BNO055_QUA_DATA_W_LSB, true);   // EN: Quaternion output
}

bno055_vector_t bno055_getVectorAccelerometer(void)
{
    return bno055_getVectorInternal(BNO055_ACC_DATA_X_LSB, false);  // EN: Accel data
}

bno055_vector_t bno055_getVectorGyroscope(void)
{
    return bno055_getVectorInternal(BNO055_GYR_DATA_X_LSB, false);  // EN: Gyro data
}

bno055_vector_t bno055_getVectorMagnetometer(void)
{
    return bno055_getVectorInternal(BNO055_MAG_DATA_X_LSB, false);  // EN: Mag data
}

bno055_vector_t bno055_getVectorLinearAccel(void)
{
    return bno055_getVectorInternal(BNO055_LIA_DATA_X_LSB, false);  // EN: Linear acceleration
}

bno055_vector_t bno055_getVectorGravity(void)
{
    return bno055_getVectorInternal(BNO055_GRV_DATA_X_LSB, false);  // EN: Gravity vector
}

/* Configure axis mapping */                         // EN: Axis remap and sign
void bno055_setAxisMap(bno055_axis_map_t axis)
{
    uint8_t axisRemap = (uint8_t)((axis.z << 4) | (axis.y << 2) | axis.x); // EN: Remap code
    uint8_t axisSign  = (uint8_t)((axis.x_sign << 2) | (axis.y_sign << 1) | axis.z_sign); // EN: Sign bits

    bno055_setPage(0);                                // EN: Page 0
    bno055_writeData(BNO055_AXIS_MAP_CONFIG, axisRemap); // EN: Write remap configuration
    bno055_writeData(BNO055_AXIS_MAP_SIGN,   axisSign);  // EN: Write sign configuration
}

/* ------------------------------------------------------------------------- */
/*                       Low level STM32 HAL functions                       */
/* ------------------------------------------------------------------------- */

/* Delay implementation in milliseconds */                // EN: Simple wrapper around HAL_Delay
void bno055_delay(int time_ms)
{
    HAL_Delay((uint32_t)time_ms);                         // EN: Block delay
}

/* Write one byte to BNO055 via I2C */                    // EN: Uses HAL_I2C_Mem_Write
void bno055_writeData(uint8_t reg, uint8_t data)
{
    HAL_StatusTypeDef res;                                // EN: HAL status code

    res = HAL_I2C_Mem_Write(bno_i2c,                      // EN: I2C handle pointer
                            BNO055_I2C_ADDR << 1,         // EN: 8 bit address
                            reg,                          // EN: Register address
                            I2C_MEMADD_SIZE_8BIT,         // EN: 8 bit register size
                            &data,                        // EN: Pointer to data byte
                            1,                            // EN: Number of bytes
                            100);                         // EN: Timeout in ms

    if (res != HAL_OK)                                   // EN: If write failed
    {
        USB_Printf("BNO I2C write error: res=%d, reg=0x%02X\r\n", res, reg); // EN: Debug to USB
    }
}

/* Read bytes from BNO055 via I2C */                      // EN: Uses HAL_I2C_Mem_Read
void bno055_readData(uint8_t reg, uint8_t *data, uint8_t len)
{
    HAL_StatusTypeDef res;                                // EN: HAL status code

    res = HAL_I2C_Mem_Read(bno_i2c,                       // EN: I2C handle pointer
                           BNO055_I2C_ADDR << 1,          // EN: 8 bit address
                           reg,                           // EN: Start register
                           I2C_MEMADD_SIZE_8BIT,          // EN: 8 bit register size
                           data,                          // EN: Destination buffer
                           len,                           // EN: Number of bytes to read
                           100);                          // EN: Timeout in ms

    if (res != HAL_OK)                                   // EN: If read failed
    {
        USB_Printf("BNO I2C read error: res=%d, reg=0x%02X\r\n", res, reg);  // EN: Debug to USB
    }
}
