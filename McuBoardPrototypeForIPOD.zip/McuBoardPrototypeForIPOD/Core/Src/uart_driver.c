/* File: uart_driver.c */
/* Why: Implement UART_Printf that sends formatted text over UART1 */

#include "uart_driver.h"          // HE: הצהרת UART_Printf
#include <string.h>               // HE: strlen
#include <stdio.h>                // HE: vsnprintf
#include <stdarg.h>               // HE: va_list va_start va_end
#include "main.h"                 // HE: הצהרת huart1

extern UART_HandleTypeDef huart1; // HE: huart1 מוגדר ב main.c

void UART_Printf(const char *fmt, ...)
{
    char buffer[256];                             // HE: באפר זמני

    va_list args;                                 // HE: רשימת ארגומנטים
    va_start(args, fmt);                          // HE: התחלת הרשימה
    vsnprintf(buffer, sizeof(buffer), fmt, args); // HE: כתיבה לפורמט
    va_end(args);                                 // HE: סיום הרשימה

    HAL_UART_Transmit(&huart1,                   // HE: שימוש ב UART1
                      (uint8_t *)buffer,         // HE: מצביע למחרוזת
                      strlen(buffer),            // HE: אורך המחרוזת
                      HAL_MAX_DELAY);            // HE: המתנה עד סיום שידור
}
