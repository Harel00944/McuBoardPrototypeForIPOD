/* File: gps.c */                                                   // HE: מימוש דרייבר GPS פשוט ל NEO-M8L על בסיס משפטים GNGLL ו GNGGA
/* Why: Parse $GNGLL for LAT LON TIME FIX and $GNGGA for ALT, then print over USB */ // HE: למה הקובץ קיים, פירוש GNGLL וגובה מ GNGGA והדפסה ל USB

#include "gps.h"                                                    // HE: כותרת הדרייבר, מבנה GPS_Data_t והצהרות פונקציות
#include "usbd_cdc_if.h"                                            // HE: הצהרת CDC_Transmit_FS עבור USB CDC
#include <string.h>                                                 // HE: פונקציות מחרוזת כמו strlen strtok
#include <stdlib.h>                                                 // HE: atof atoi להמרה ממחרוזת למספר
#include <stdio.h>                                                  // HE: snprintf לבניית מחרוזת להדפסה

#define GPS_LINE_BUFFER_SIZE 128                                    // HE: גודל באפר לשורה אחת של משפט NMEA

static UART_HandleTypeDef *gps_huart = NULL;                        // HE: מצביע ל UART שבו מחובר ה GPS
static uint8_t gps_rx_byte = 0;                                     // HE: בית יחיד לקבלה באינטרפט
static char gps_line_buffer[GPS_LINE_BUFFER_SIZE];                  // HE: באפר למחרוזת NMEA אחת
static uint16_t gps_line_index = 0;                                 // HE: אינדקס כתיבה באורך המחרוזת
static volatile uint8_t gps_new_data_flag = 0;                      // HE: דגל שמסמן שיש נתונים חדשים להדפסה
static GPS_Data_t gps_last_data;                                    // HE: נתוני GPS האחרונים שעובדו בהצלחה

/* הצהרת פונקציות פנימיות */
static void GPS_ProcessLine(char *line);                            // HE: פירוש שורת NMEA אם היא GNGLL או GNGGA
static void GPS_ParseGLL(char *line);                               // HE: פירוש משפט GNGLL עבור LAT LON TIME FIX
static void GPS_ParseGGA(char *line);                               // HE: פירוש משפט GNGGA עבור ALTITUDE
static void GPS_ParseGSA(char *line);
static double GPS_NmeaToDegrees(const char *field, char hemi);      // HE: המרת שדה ddmm.mmmm או dddmm.mmmm למעלות עשרוניות

void GPS_Init(UART_HandleTypeDef *huart)                            // HE: פונקציית אתחול דרייבר ה GPS
{
    gps_huart = huart;                                              // HE: שמירת מצביע ל UART שבו ה GPS מחובר
    gps_line_index = 0;                                             // HE: איפוס אינדקס באפר השורה
    gps_new_data_flag = 0;                                          // HE: איפוס דגל הנתונים החדשים
    memset(&gps_last_data, 0, sizeof(gps_last_data));               // HE: איפוס מבנה הנתונים האחרון כולל גובה

    HAL_UART_Receive_IT(gps_huart,                                  // HE: התחלת קבלת בית בודד מה GPS באינטרפט
                        &gps_rx_byte,                               // HE: כתובת הבית שיתקבל
                        1);                                         // HE: אורך הקבלה הוא בית אחד
}

void GPS_RxCpltCallback(void)                                       // HE: פונקציה שתקרא מתוך HAL_UART_RxCpltCallback עבור UART של ה GPS
{
    uint8_t b = gps_rx_byte;                                        // HE: שמירת הבית שהתקבל במשתנה מקומי

    if (b == '\r') {                                                // HE: אם זה תו carriage return מתעלמים ממנו
        /* do nothing */                                            // HE: לא עושים כלום עבור \r
    } else if (b == '\n') {                                         // HE: אם קיבלנו סוף שורה NMEA
        if (gps_line_index > 0 && gps_line_index < GPS_LINE_BUFFER_SIZE) { // HE: יש שורה חוקית בתוך גבולות הבאפר
            gps_line_buffer[gps_line_index] = '\0';                 // HE: הוספת תו סיום מחרוזת
            GPS_ProcessLine(gps_line_buffer);                       // HE: פירוש השורה לפי סוג המשפט
        }
        gps_line_index = 0;                                         // HE: איפוס אינדקס לבניית השורה הבאה
    } else {                                                        // HE: תו רגיל באמצע השורה
        if (gps_line_index < (GPS_LINE_BUFFER_SIZE - 1)) {          // HE: כל עוד יש מקום בבאפר
            gps_line_buffer[gps_line_index++] = (char)b;            // HE: הוספת התו לבאפר והגדלת אינדקס
        } else {                                                    // HE: במקרה של גלישה מעבר לבאפר
            gps_line_index = 0;                                     // HE: איפוס הבאפר כדי לא להיתקע על שורה ארוכה מדי
        }
    }

    HAL_UART_Receive_IT(gps_huart,                                  // HE: הפעלת קבלה מחדש של בית נוסף מה GPS
                        &gps_rx_byte,                               // HE: מצביע למשתנה הבית
                        1);                                         // HE: קבלה של בית אחד
}

static void GPS_ProcessLine(char *line)                                  // HE: בחירת פונקציית פירוש לפי סוג המשפט
{
    if (strncmp(line, "$GNGLL", 6) == 0) {                               // HE: אם השורה מתחילה ב $GNGLL זה משפט מיקום
        GPS_ParseGLL(line);                                              // HE: פירוש GLL עבור LAT LON TIME FIX
    } else if (strncmp(line, "$GNGGA", 6) == 0) {                        // HE: אם השורה מתחילה ב $GNGGA זה משפט גובה
        GPS_ParseGGA(line);                                              // HE: פירוש GGA עבור ALTITUDE
    } else if (   strncmp(line, "$GPGSA", 6) == 0                        // HE: משפט GSA עבור GPS בפורמט GP
               || strncmp(line, "$GLGSA", 6) == 0                        // HE: משפט GSA עבור GLONASS בפורמט GL
               || strncmp(line, "$GAGSA", 6) == 0                        // HE: משפט GSA עבור GALILEO בפורמט GA
               || strncmp(line, "$GBGSA", 6) == 0                        // HE: משפט GSA עבור BEIDOU בפורמט GB
               || strncmp(line, "$GNGSA", 6) == 0) {

    	// DEBUG: Print raw GSA to USB
    //	char dbg[140];
    //	int n = snprintf(dbg, sizeof(dbg), "RAW GSA: %s\r\n", line);
    //	CDC_Transmit_FS((uint8_t *)dbg, n);
// HE: משפט GSA משולב GN של u-blox
        GPS_ParseGSA(line);                                              // HE: פירוש GSA לספירת לוויינים המשתתפים בפיקס
    } else {                                                             // HE: כל משפט אחר כרגע לא מעניין אותנו
        /* ignore */                                                     // HE: מתעלמים משורה מסוג אחר
    }
}


static void GPS_ParseGLL(char *line)                                     // HE: פירוש משפט GNGLL בודד
{
    char *token;                                                         // HE: מצביע לטוקן הנוכחי במחרוזת
    char *rest = line;                                                   // HE: מצביע לשאר המחרוזת עבור strtok_r
    int field_index = 0;                                                 // HE: אינדקס שדה כדי לדעת איזה טוקן זה
    char lat_str[20] = {0};                                              // HE: מחרוזת זמנית לשדה LAT
    char lon_str[20] = {0};                                              // HE: מחרוזת זמנית לשדה LONG
    char ns = 'N';                                                       // HE: סימון צפון או דרום
    char ew = 'E';                                                       // HE: סימון מזרח או מערב
    char time_str[16] = {0};                                             // HE: מחרוזת זמנית לשדה הזמן
    char status = 'V';                                                   // HE: סטטוס ברירת מחדל לא תקין V

    while ((token = strtok_r(rest, ",", &rest)) != NULL) {               // HE: לולאה על כל השדות המופרדים בפסיק
        switch (field_index) {                                           // HE: בחירה לפי מספר השדה
        case 0:                                                          // HE: שדה 0 הוא "$GNGLL" סוג המשפט
            break;                                                       // HE: לא עושים כלום בשדה הזה
        case 1:                                                          // HE: שדה 1 הוא LAT בפורמט ddmm.mmmm
            strncpy(lat_str, token, sizeof(lat_str) - 1);                // HE: שמירת ה LAT במשתנה זמני
            break;                                                       // HE: סיום טיפול בשדה 1
        case 2:                                                          // HE: שדה 2 הוא N או S
            if (token[0] != '\0') {                                      // HE: בדיקה שהמחרוזת לא ריקה
                ns = token[0];                                           // HE: שמירת התו N או S
            }
            break;                                                       // HE: סיום טיפול בשדה 2
        case 3:                                                          // HE: שדה 3 הוא LONG בפורמט dddmm.mmmm
            strncpy(lon_str, token, sizeof(lon_str) - 1);                // HE: שמירת ה LONG במשתנה זמני
            break;                                                       // HE: סיום טיפול בשדה 3
        case 4:                                                          // HE: שדה 4 הוא E או W
            if (token[0] != '\0') {                                      // HE: בדיקה שהמחרוזת לא ריקה
                ew = token[0];                                           // HE: שמירת התו E או W
            }
            break;                                                       // HE: סיום טיפול בשדה 4
        case 5:                                                          // HE: שדה 5 הוא הזמן hhmmss.sss
            strncpy(time_str, token, sizeof(time_str) - 1);              // HE: שמירת הזמן במחרוזת זמנית
            break;                                                       // HE: סיום טיפול בשדה 5
        case 6:                                                          // HE: שדה 6 הוא status A או V
            if (token[0] != '\0') {                                      // HE: בדיקה שהמחרוזת לא ריקה
                status = token[0];                                       // HE: שמירת הסטטוס A או V
            }
            break;                                                       // HE: סיום טיפול בשדה 6
        default:                                                         // HE: שדות נוספים פחות חשובים לנו כרגע
            break;                                                       // HE: מתעלמים משדות מעבר למספר 6
        }

        field_index++;                                                   // HE: הגדלת מונה השדות
    }

    if (lat_str[0] == '\0' || lon_str[0] == '\0' ||                      // HE: אם LAT או LONG ריקים
        time_str[0] == '\0') {                                           // HE: או אם הזמן ריק
        return;                                                          // HE: אין נתונים מספיקים יוצאים
    }

    GPS_Data_t data = gps_last_data;                                     // HE: מתחילים מהנתונים האחרונים כולל גובה וספירות לוויינים קיימות
    data.lat_deg = GPS_NmeaToDegrees(lat_str, ns);                       // HE: המרת LAT למעלות עשרוניות לפי N או S
    data.lon_deg = GPS_NmeaToDegrees(lon_str, ew);                       // HE: המרת LONG למעלות עשרוניות לפי E או W

    data.hour = 0;                                                       // HE: אתחול שעה ל 0
    data.minute = 0;                                                     // HE: אתחול דקה ל 0
    data.second = 0;                                                     // HE: אתחול שניה ל 0

    if (strlen(time_str) >= 6) {                                         // HE: אם יש לפחות 6 ספרות בזמן
        char buf[3];                                                     // HE: באפר קטן לזוג ספרות

        buf[0] = time_str[0];                                            // HE: ספרה ראשונה של שעה
        buf[1] = time_str[1];                                            // HE: ספרה שניה של שעה
        buf[2] = '\0';                                                   // HE: סיום מחרוזת
        data.hour = (uint8_t)atoi(buf);                                  // HE: המרת השעה ממחרוזת למספר

        buf[0] = time_str[2];                                            // HE: ספרה ראשונה של דקה
        buf[1] = time_str[3];                                            // HE: ספרה שניה של דקה
        buf[2] = '\0';                                                   // HE: סיום מחרוזת
        data.minute = (uint8_t)atoi(buf);                                // HE: המרת הדקה ממחרוזת למספר

        buf[0] = time_str[4];                                            // HE: ספרה ראשונה של שניה
        buf[1] = time_str[5];                                            // HE: ספרה שניה של שניה
        buf[2] = '\0';                                                   // HE: סיום מחרוזת
        data.second = (uint8_t)atoi(buf);                                // HE: המרת השניה ממחרוזת למספר
    }

    data.fix = (status == 'A') ? 1 : 0;                                  // HE: אם status הוא A יש FIX אחרת אין FIX

    gps_last_data = data;                                                // HE: שמירת הנתונים במבנה הגלובלי האחרון
    gps_new_data_flag = 1;                                               // HE: סימון שיש נתוני GPS חדשים זמינים להדפסה
}

static void GPS_ParseGGA(char *line)                                     // HE: פירוש משפט GNGGA עבור גובה
{
    char *token;                                                         // HE: מצביע לטוקן הנוכחי במחרוזת
    char *rest = line;                                                   // HE: מצביע לשאר המחרוזת עבור strtok_r
    int field_index = 0;                                                 // HE: אינדקס שדה כדי לדעת איזה טוקן זה
    char alt_str[20] = {0};                                              // HE: מחרוזת זמנית לשדה הגובה

    while ((token = strtok_r(rest, ",", &rest)) != NULL) {               // HE: לולאה על כל השדות במכתב GGA
        switch (field_index) {                                           // HE: בחירה לפי מספר השדה
        case 9:                                                          // HE: שדה 9 הוא ALTITUDE במטרים מעל פני הים
            strncpy(alt_str, token, sizeof(alt_str) - 1);                // HE: שמירת הגובה במחרוזת זמנית
            break;                                                       // HE: סיום טיפול בשדה 9
        default:                                                         // HE: שדות אחרים לא מעניינים אותנו כרגע
            break;                                                       // HE: מתעלמים מהם
        }
        field_index++;                                                   // HE: הגדלת מונה השדות
    }

    if (alt_str[0] == '\0') {                                            // HE: אם לא קיבלנו גובה חוזרים בלי לעדכן
        return;                                                          // HE: אין נתון גובה
    }

    gps_last_data.altitude_m = atof(alt_str);                            // HE: המרת מחרוזת גובה למספר נקודה צפה במטרים
}

static void GPS_ParseGSA(char *line)                                     // HE: פירוש משפט GSA לספירת לוויינים המשתתפים בפיקס
{
    char *token;                                                         // HE: מצביע לטוקן הנוכחי במחרוזת
    char *rest = line;                                                   // HE: מצביע לשאר המחרוזת עבור strtok_r
    int  field_index = 0;                                                // HE: אינדקס שדה כדי לדעת איזה טוקן זה
    char fix_type = '1';                                                 // HE: סוג הפיקס, ברירת מחדל 1 no fix
    uint8_t used_count = 0;                                              // HE: מונה לוויינים המשתתפים בפיקס במשפט הנוכחי

    /* HE: נפרק את משפט ה GSA לשדות לפי פסיק */
    while ((token = strtok_r(rest, ",", &rest)) != NULL) {               // HE: לולאה על כל השדות של משפט GSA
        switch (field_index) {                                           // HE: בחירה לפי מספר השדה

        case 2:                                                          // HE: שדה 2 הוא fix type: 1 no fix, 2 2D, 3 3D
            if (token[0] != '\0') {                                      // HE: בדיקה שהשדה לא ריק
                fix_type = token[0];                                     // HE: שמירת סוג הפיקס
            }
            break;                                                       // HE: סיום טיפול בשדה 2

        case 3:                                                          // HE: שדות 3 עד 14 – רשימת הלוויינים המשתתפים בפיקס
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 10:
        case 11:
        case 12:
        case 13:
        case 14:
            if (token[0] != '\0') {                                      // HE: אם השדה לא ריק יש לווין פעיל בפיקס
                used_count++;                                            // HE: הגדלת מונה הלוויינים
            }
            break;                                                       // HE: סוף טיפול בשדות הלוויינים

        default:                                                         // HE: שדות אחרים כמו PDOP/HDOP/VDOP לא מעניינים כרגע
            break;                                                       // HE: דילוג
        }

        field_index++;                                                   // HE: הגדלת מונה השדות
    }

    GPS_Data_t data = gps_last_data;                                     // HE: התחלה ממצב הנתונים האחרון

    /* HE: אם אין פיקס אמיתי לפי GSA – מנקים את הספירה */
    if (fix_type == '1' || fix_type == '0') {                            // HE: 1 או 0 משמעותם no fix
        data.used_gps     = 0;                                           // HE: אין לוויינים פעילים
        data.used_glonass = 0;
        data.used_galileo = 0;
        data.used_beidou  = 0;
    } else {                                                             // HE: יש פיקס 2D או 3D
        /* HE: אצלך מגיע רק משפט GNGSA משולב, לכן נספור הכל כ GPS */
        data.used_gps     = used_count;                                  // HE: מספר הלוויינים בפיקס
        data.used_glonass = 0;                                           // HE: כרגע לא מפרידים בין מערכות
        data.used_galileo = 0;
        data.used_beidou  = 0;
    }

    gps_last_data = data;                                                // HE: עדכון המבנה הגלובלי עם ספירות מעודכנות
    gps_new_data_flag = 1;                                               // HE: סימון שיש נתונים חדשים להדפסה
}

static double GPS_NmeaToDegrees(const char *field, char hemi)            // HE: המרת שדה NMEA ddmm.mmmm או dddmm.mmmm למעלות
{
    double raw = atof(field);                                            // HE: המרה ממחרוזת למספר נקודה צפה
    int degrees = (int)(raw / 100.0);                                    // HE: חלק המעלות מתקבל מחלוקה ב 100
    double minutes = raw - (degrees * 100.0);                            // HE: החלק של הדקות הוא השארית אחרי המעלות
    double deg = degrees + (minutes / 60.0);                             // HE: המרה ממעלות ודקות למעלות עשרוניות

    if (hemi == 'S' || hemi == 's' ||                                    // HE: אם ההמיספרה דרום
        hemi == 'W' || hemi == 'w') {                                    // HE: או מערב
        deg = -deg;                                                      // HE: הופכים סימן כדי לקבל קואורדינטה שלילית
    }

    return deg;                                                          // HE: החזרת התוצאה במעלות עשרוניות
}

void GPS_PrintStatusLine(void)                                           // HE: פונקציה להדפסת שורת מצב ל Tera Term דרך USB CDC
{
    if (!gps_new_data_flag) {                                            // HE: אם אין נתונים חדשים אין מה להדפיס
        return;                                                          // HE: יציאה מהירה מהפונקציה
    }

    gps_new_data_flag = 0;                                               // HE: איפוס דגל הנתונים החדשים
    char buf[160];                                                       // HE: באפר למחרוזת שתישלח ל Tera Term

    snprintf(buf,                                                        // HE: בניית המחרוזת בפורמט קריא
             sizeof(buf),                                                // HE: גודל הבאפר כדי למנוע גלישה
             "LAT: %.6f LON: %.6f ALT: %.1f m TIME: %02u:%02u:%02u FIX: %s, Used Sats For Fix:%u GLN:%u GAL:%u BEI:%u\r\n", // HE: פורמט ההדפסה כולל גובה וספירת לוויינים
             gps_last_data.lat_deg,                                      // HE: הכנסת קו רוחב למחרוזת
             gps_last_data.lon_deg,                                      // HE: הכנסת קו אורך למחרוזת
             gps_last_data.altitude_m,                                   // HE: הכנסת הגובה במטרים למחרוזת
             gps_last_data.hour,                                         // HE: הכנסת שעה למחרוזת
             gps_last_data.minute,                                       // HE: הכנסת דקה למחרוזת
             gps_last_data.second,                                       // HE: הכנסת שניה למחרוזת
             gps_last_data.fix ? "YES" : "NO",                           // HE: הכנסת טקסט YES אם יש FIX או NO אם אין
             gps_last_data.used_gps,                                     // HE: מספר לווייני GPS שמשתתפים בפיקס
             gps_last_data.used_glonass,                                 // HE: מספר לווייני GLONASS שמשתתפים בפיקס
             gps_last_data.used_galileo,                                 // HE: מספר לווייני GALILEO שמשתתפים בפיקס
             gps_last_data.used_beidou);                                 // HE: מספר לווייני BEIDOU שמשתתפים בפיקס

    CDC_Transmit_FS((uint8_t *)buf,                                      // HE: שליחת המחרוזת דרך USB CDC למחשב
                    (uint16_t)strlen(buf));                              // HE: שליחת אורך המחרוזת בפועל
}
